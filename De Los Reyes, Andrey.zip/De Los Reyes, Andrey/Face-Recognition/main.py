import sys
import json
import face_recognition
import os
from pathlib import Path

# Function to load known faces from the image directory
def load_known_faces(image_dir):
    known_face_encodings = []
    known_face_names = []

    # Check if the directory exists
    if not os.path.exists(image_dir):
        print(f"Known faces directory not found: {image_dir}")
        return known_face_encodings, known_face_names

    # Iterate over all the images in the directory
    for image_path in Path(image_dir).glob('*.jpg'):
        # Load the image and extract the face encodings
        image = face_recognition.load_image_file(image_path)
        face_encodings = face_recognition.face_encodings(image)

        # If a face encoding was found, use it
        if face_encodings:
            known_face_encodings.append(face_encodings[0])
            # Extract the name from the file (the file name without the extension)
            known_face_names.append(image_path.stem)

    return known_face_encodings, known_face_names

# Function to recognize faces from an image path
def recognize_faces(image_path, known_face_encodings, known_face_names):
    try:
        # Load the image to be checked
        image = face_recognition.load_image_file(image_path)

        # Find face encodings in the image
        face_locations = face_recognition.face_locations(image)
        face_encodings = face_recognition.face_encodings(image, face_locations)

        recognized_names = []
        for face_encoding in face_encodings:
            matches = face_recognition.compare_faces(known_face_encodings, face_encoding)
            name = "Unknown"
            if True in matches:
                first_match_index = matches.index(True)
                name = known_face_names[first_match_index]
            recognized_names.append(name)

        # Return both the recognized names and the count of recognized faces
        return recognized_names, len(face_encodings)  # Count of faces found
    except Exception as e:
        return [f"Error processing image: {str(e)}"], 0

# Main function to execute the script
if __name__ == "__main__":
    if len(sys.argv) != 3:  # Expecting email and image path
        print(json.dumps(["Error: Please provide the email and image path."]))
        sys.exit(1)

    user_email = sys.argv[1]  # Get email from arguments
    checkin_image_path = sys.argv[2]  # Get image path from arguments
    
    # Load known faces from the directory
    known_faces_dir = f"/Users/Andrey_Delos_Reyes/Documents/De Los Reyes, Andrey/Documents/user/images/{user_email}"
    known_face_encodings, known_face_names = load_known_faces(known_faces_dir)

    # Recognize faces in the check-in image provided via command-line argument
    recognized_names, face_count = recognize_faces(checkin_image_path, known_face_encodings, known_face_names)

    # Prepare the output with recognized names and count
    output = {
        "recognized_names": recognized_names,
        "face_count": face_count
    }

    # Output recognized names and count as a JSON object
    print(json.dumps(output))
